
'use strict';
const field=name=>document.querySelector('[data-testid="'+name+'"]');
const format=new Intl.NumberFormat('vi-VN');
function display(name,value){field(name).textContent=format.format(value);}
function showError(message){
  const error=field('error'); error.textContent=message; error.hidden=false; field('result').hidden=true;
}
function divide(event){
  event.preventDefault();
  const total=field('total').value.trim(), people=field('people').value.trim();
  if(!/^(\d+|\d{1,3}(\.\d{3})+)$/.test(total)){showError('Nhập tổng tiền bằng số đồng nguyên không âm.');return;}
  if(!/^\d+$/.test(people) || BigInt(people)===0n){showError('Nhập số người nguyên lớn hơn 0.');return;}
  const amount=BigInt(total.replaceAll('.','')), count=BigInt(people);
  const base=amount/count, remainder=amount%count;
  const firstCount=remainder===0n?count:remainder;
  const firstAmount=base+(remainder===0n?0n:1n);
  field('error').hidden=true; field('error').textContent='';
  field('result').hidden=false;
  document.querySelector('#first-label').textContent=remainder===0n?'người':'người đầu';
  display('first-count',firstCount); display('first-amount',firstAmount);
  document.querySelector('#second').hidden=remainder===0n;
  display('second-count',count-firstCount); display('second-amount',base);
}
document.querySelector('#split').addEventListener('submit',divide);
