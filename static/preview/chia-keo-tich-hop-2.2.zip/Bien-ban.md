# Chia Kèo · Tích hợp 2.1

Xây app Chia Kèo offline nhiều tệp index.html, app.js và style.css; nhập tổng tiền và số người.

Trạng thái: done

Runtime: ollama

## Tiếp nhận ticket · Mai

Biên bản fixture

## Duyệt phạm vi · Quân

Biên bản fixture

## Đặc tả hành vi · An

Biên bản fixture

## Review yêu cầu · Uyên

Biên bản fixture

## Phản biện thiết kế · Vy

Biên bản fixture

## Thiết kế thay đổi · Yến

Biên bản fixture

## Duyệt thiết kế · Phong

Biên bản fixture

## Thực hiện phiếu · Yến

Biên bản fixture

## Thực hiện phiếu · Phong

Biên bản fixture

## Nhận bàn giao · Vy

Biên bản fixture

## Nhận bàn giao · Vy

Biên bản fixture

## Thực hiện phiếu · Hà

Biên bản fixture

## Thực hiện phiếu · Hà

Biên bản fixture

## Nhận bàn giao · Sơn

Biên bản fixture

## Thực hiện phiếu · Hà

Biên bản fixture

## Nhận bàn giao · Sơn

Biên bản fixture

## Viết mã · Yến

Biên bản fixture

## Kiểm tra bản mã · Vy

Yêu cầu sửa. chia-dư · Mong đợi (1, 33334, 2, 33333) · Thực tế (2, 33333, 1, 33334) | dấu-chấm · Mong đợi (1, 33334, 2, 33333) · Thực tế (2, 33333, 1, 33334) | người-vượt-đồng · Mong đợi (2, 1, 1, 0) · Thực tế (1, 0, 2, 1) | khôi-phục · Mong đợi (1, 33334, 2, 33333) · Thực tế (2, 33333, 1, 33334)

## Thực hiện phiếu · Hà

Biên bản fixture

## Nhận bàn giao · Sơn

Biên bản fixture

## Viết mã · Yến

Biên bản fixture

## Kiểm tra bản mã · Vy

Biên bản fixture Máy đã kiểm tra 14 mục.

## Bàn giao bản phát hành · Quân

Biên bản fixture