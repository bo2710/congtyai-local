# Cộng số · Bằng chứng 2.2

Viết hàm cộng hai số nguyên. Từ chối dữ liệu chữ.

Trạng thái: ready

Runtime: ollama

## Tiếp nhận ticket · Mai

Biên bản fixture độc lập

## Duyệt phạm vi · Quân

Biên bản fixture độc lập

## Đặc tả hành vi · An

Biên bản fixture độc lập

## Review yêu cầu · Uyên

Biên bản fixture độc lập

## Phản biện thiết kế · Vy

Biên bản fixture độc lập

## Thiết kế thay đổi · Khoa

Biên bản fixture độc lập

## Duyệt thiết kế · Trúc

Biên bản fixture độc lập

## Viết mã · Khoa

Biên bản fixture độc lập

## Kiểm tra bản mã · Vy

Yêu cầu sửa. add-positive · Mong đợi 5 · Thực tế 0 | add-negative · Mong đợi -2 · Thực tế 0 | add-zero · Mong đợi 8 · Thực tế 0 | reject-input · Mong đợi {'raises': {'type': 'TypeError', 'message': 'Chỉ chấp nhận số nguyên'}} · Thực tế 0