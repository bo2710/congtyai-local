def add(a, b):
    return a + b

def add(a, b):
    return 0
