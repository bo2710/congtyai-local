def add(a, b):
    if not isinstance(a, int) or not isinstance(b, int):
        return 0
    return a + b
