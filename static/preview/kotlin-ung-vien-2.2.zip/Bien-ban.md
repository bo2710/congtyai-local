# Hồ sơ kiểm

Viết ứng dụng Kotlin để sắp xếp danh sách

Trạng thái: blocked

Runtime: ollama

## Tiếp nhận ticket · Mai

Biên bản fixture độc lập

## Duyệt phạm vi · Quân

Biên bản fixture độc lập

## Đặc tả hành vi · An

Biên bản fixture độc lập

## Review yêu cầu · Uyên

Biên bản fixture độc lập

## Phản biện thiết kế · Vy

Biên bản fixture độc lập

## Thiết kế thay đổi · Khoa

Biên bản fixture độc lập

## Duyệt thiết kế · Trúc

Biên bản fixture độc lập

## Viết mã · Khoa

Biên bản fixture độc lập

## Kiểm tra bản mã · Vy

Chưa kiểm được hành vi bằng runner hiện có · Đối chiếu sản phẩm với yêu cầu: Viết ứng dụng Kotlin để sắp xếp danh sách | Thiếu bằng chứng hành vi: Đối chiếu sản phẩm với yêu cầu: Viết ứng dụng Kotlin để sắp xếp danh sách