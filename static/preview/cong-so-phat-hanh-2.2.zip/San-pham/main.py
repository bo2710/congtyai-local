def add(a, b):
    if not isinstance(a, int) or not isinstance(b, int):
        raise TypeError('Chỉ chấp nhận số nguyên')
    return a + b
