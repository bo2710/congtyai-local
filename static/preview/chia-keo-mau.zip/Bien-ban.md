# Chia Kèo

Viết một tệp index.html Chia Kèo chạy offline. Nhập tổng tiền và số người. Chia phần dư cho những người đầu tiên.

Trạng thái: done

Runtime: ollama

## Tiếp nhận ticket · Mai

Yến chịu trách nhiệm ứng dụng offline.

## Duyệt phạm vi · Phong

Phạm vi một tệp index.html.

## Đặc tả hành vi · An

Số đồng nguyên và phần dư cho những người đầu.

## Phản biện thiết kế · Vy

Các ca tổng tiền 100.000 chia 3 và 120.000 chia 4 phải bảo toàn tổng.

## Thiết kế thay đổi · Yến

Dùng HTML và JavaScript thuần.

## Duyệt thiết kế · Phong

Chấp nhận bảo toàn tiền và số người.

## Viết mã · Yến

Yến đã giao index.html để Vy kiểm.

## Kiểm tra bản mã · Vy

Yêu cầu sửa. chia-dư · Mong đợi (1, 33334, 2, 33333) · Thực tế (2, 33333, 1, 33334) | dấu-chấm · Mong đợi (1, 33334, 2, 33333) · Thực tế (2, 33333, 1, 33334) | người-vượt-đồng · Mong đợi (2, 1, 1, 0) · Thực tế (1, 0, 2, 1) | khôi-phục · Mong đợi (1, 33334, 2, 33333) · Thực tế (2, 33333, 1, 33334)

## Viết mã · Yến

Yến đã giao index.html để Vy kiểm.

## Kiểm tra bản mã · Vy

Vy đối chiếu trên bản do Yến giao. Quyết định dựa trên kết quả công cụ. Máy đã kiểm tra 14 mục.

## Bàn giao bản phát hành · Phong

Vy đối chiếu trên bản do Yến giao. Quyết định dựa trên kết quả công cụ.