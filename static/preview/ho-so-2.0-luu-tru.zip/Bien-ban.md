# Hồ sơ 2.0 thực

Viết hàm cộng hai số nguyên Python

Trạng thái: done

Runtime: ollama

## Viết mã · Yến

Đã giao phiên bản 2.0